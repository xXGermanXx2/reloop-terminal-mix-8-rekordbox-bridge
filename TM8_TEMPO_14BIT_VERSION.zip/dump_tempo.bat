@echo off
setlocal
cd /d "%~dp0"
if exist tm8_midi_dump.jsonl del /q tm8_midi_dump.jsonl
 echo Starte Pitchwheel-Dump.
echo Bewege jetzt nur die Tempo-Fader und beende danach mit STRG+C.
py -3.12 terminal_mix8_rekordbox.py --dump
pause
